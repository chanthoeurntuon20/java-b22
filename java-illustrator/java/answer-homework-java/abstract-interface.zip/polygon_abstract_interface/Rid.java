package polygon_abstract_interface;
public class Rid {
	int sizeLength;
	public  Rid(int sizeLength){
		this.sizeLength = sizeLength;
	}
}
