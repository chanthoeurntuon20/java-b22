package abstract_interface1;

public interface Validable {
	boolean isValid();
}
